import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { QualidadeRegistroStatus } from '@prisma/client';
import { PrismaService } from '../prisma.service';
import { CreateQualidadeRegistroDto } from './dto/create-qualidade-registro.dto';
import { UpdateQualidadeRegistroDto } from './dto/update-qualidade-registro.dto';

export type UsuarioOrionQualidadeReq = {
  id: number;
  nome: string;
  matricula: string;
  sistemasPermitidos: string[];
};

@Injectable()
export class OrionQualidadeService {
  constructor(private readonly prisma: PrismaService) {}

  podeAcessarOrionQualidade(usuario: UsuarioOrionQualidadeReq): boolean {
    const ids = (usuario.sistemasPermitidos ?? []).map((s) =>
      String(s).trim().toUpperCase(),
    );
    return ids.includes('ORION_QUALIDADE');
  }

  private assertAcessoModulo(usuario: UsuarioOrionQualidadeReq): void {
    if (!this.podeAcessarOrionQualidade(usuario)) {
      throw new ForbiddenException(
        'Acesso ao Órion Qualidade não autorizado para este perfil. Um administrador deve incluir o módulo "Órion Qualidade" em seus sistemas permitidos (SAD → Usuários).',
      );
    }
  }

  getPublicMeta() {
    return {
      sistema: 'orion-qualidade',
      nome: 'Órion Qualidade',
      versao: '0.2.0',
      fase: 'dashboard-visual',
    };
  }

  sessaoResumo(usuario: UsuarioOrionQualidadeReq) {
    const pode = this.podeAcessarOrionQualidade(usuario);
    return {
      ok: true,
      sistema: 'orion-qualidade',
      podeAcessarModulo: pode,
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        matricula: usuario.matricula,
      },
      mensagem: pode
        ? 'Módulo disponível: registros de gestão da qualidade.'
        : 'Seu usuário autenticou na API, mas não possui permissão para usar o Órion Qualidade.',
    };
  }

  async listarRegistros(usuario: UsuarioOrionQualidadeReq) {
    this.assertAcessoModulo(usuario);
    return this.prisma.qualidadeRegistro.findMany({
      orderBy: { createdAt: 'desc' },
    });
  }

  async criarRegistro(
    usuario: UsuarioOrionQualidadeReq,
    dto: CreateQualidadeRegistroDto,
  ) {
    this.assertAcessoModulo(usuario);
    return this.prisma.qualidadeRegistro.create({
      data: {
        titulo: dto.titulo.trim(),
        descricao: dto.descricao?.trim() || null,
        criadoPorId: usuario.id,
        criadoPorNome: usuario.nome,
      },
    });
  }

  async atualizarRegistro(
    usuario: UsuarioOrionQualidadeReq,
    id: number,
    dto: UpdateQualidadeRegistroDto,
  ) {
    this.assertAcessoModulo(usuario);
    const existente = await this.prisma.qualidadeRegistro.findUnique({
      where: { id },
    });
    if (!existente) {
      throw new NotFoundException('Registro não encontrado.');
    }

    if (
      dto.titulo === undefined &&
      dto.descricao === undefined &&
      dto.status === undefined
    ) {
      throw new BadRequestException(
        'Informe ao menos um campo para atualizar (título, descrição ou status).',
      );
    }

    const data: {
      titulo?: string;
      descricao?: string | null;
      status?: QualidadeRegistroStatus;
      atualizadoPorId: number;
      atualizadoPorNome: string;
    } = {
      atualizadoPorId: usuario.id,
      atualizadoPorNome: usuario.nome,
    };

    if (dto.titulo !== undefined) {
      data.titulo = dto.titulo.trim();
    }
    if (dto.descricao !== undefined) {
      data.descricao = dto.descricao.trim() || null;
    }
    if (dto.status !== undefined) {
      data.status = dto.status;
    }

    return this.prisma.qualidadeRegistro.update({
      where: { id },
      data,
    });
  }
}
