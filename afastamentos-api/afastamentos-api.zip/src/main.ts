import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import { json } from 'express';
import { AppModule } from './app.module';
import { ensureInitialUser } from './on-startup';

async function bootstrap() {
  // Garantir que o usuário inicial existe antes de iniciar a API
  await ensureInitialUser();

  const app = await NestFactory.create(AppModule);
  
  // Aumentar o limite do body parser para permitir upload de imagens em base64 (até 10MB)
  app.use(json({ limit: '10mb' }));
  
  // Configurar Helmet para adicionar headers de segurança
  const isProduction = process.env.NODE_ENV === 'production';
  const frontendUrl = process.env.FRONTEND_URL;
  const apiUrl = process.env.API_URL;
  const connectSrc = ["'self'"];
  if (frontendUrl) connectSrc.push(frontendUrl);
  if (apiUrl) connectSrc.push(apiUrl);
  app.use(helmet({
    contentSecurityPolicy: isProduction ? {
      directives: {
        defaultSrc: ["'self'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        fontSrc: ["'self'", 'data:'],
        connectSrc,
      },
    } : false, // Em desenvolvimento manter flexível
    crossOriginEmbedderPolicy: false, // Desabilitar para permitir recursos externos se necessário
  }));
  
  // Configurar CORS com origens permitidas
  const orionSuporteUrl = process.env.ORION_SUPORTE_FRONTEND_URL;

  const allowedOrigins = [
    'http://localhost:5173', // Vite dev Órion SAD
    'http://localhost:5174', // legado / outro dev
    'http://localhost:5180', // Vite dev Órion Suporte (porta dedicada)
    'http://localhost:4173', // Vite preview SAD
    'http://localhost:4180', // Vite preview Suporte
    'http://127.0.0.1:5173',
    'http://127.0.0.1:5174',
    'http://127.0.0.1:5180',
    'http://127.0.0.1:4173',
    'http://127.0.0.1:4180',
  ];

  // Adicionar origem customizada se definida em variável de ambiente
  if (frontendUrl) {
    allowedOrigins.push(frontendUrl);
  }
  if (orionSuporteUrl) {
    allowedOrigins.push(orionSuporteUrl);
  }

  app.enableCors({
    origin: isProduction ? allowedOrigins : true,
    credentials: true, // Permite cookies e headers de autenticação
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  });
  
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  const port = Number(process.env.PORT ?? 3002);
  await app.listen(port, '0.0.0.0');
  const host = process.env.SERVER_HOST ?? 'localhost';
  console.log(`🚀 API disponível em:`);
  console.log(`   • http://localhost:${port}`);
  console.log(`   • http://${host}:${port}`);
}
bootstrap();
