import { Alert, Box, Paper, Stack, Typography } from '@mui/material';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

/** Paleta alinhada ao tema (primary / secondary / accent). */
const CORES = ['#38bdf8', '#a78bfa', '#34d399', '#fbbf24', '#f472b6'];

const DADOS_MENSAL = [
  { mes: 'Out', registros: 12 },
  { mes: 'Nov', registros: 19 },
  { mes: 'Dez', registros: 15 },
  { mes: 'Jan', registros: 22 },
  { mes: 'Fev', registros: 28 },
  { mes: 'Mar', registros: 24 },
];

const DADOS_STATUS = [
  { name: 'Aberto', value: 18 },
  { name: 'Em tratamento', value: 11 },
  { name: 'Encerrado', value: 34 },
];

const DADOS_TENDENCIA = [
  { mes: 'Out', indice: 62 },
  { mes: 'Nov', indice: 68 },
  { mes: 'Dez', indice: 65 },
  { mes: 'Jan', indice: 72 },
  { mes: 'Fev', indice: 78 },
  { mes: 'Mar', indice: 81 },
];

const tooltipStyle = {
  backgroundColor: '#1e293b',
  border: '1px solid #334155',
  borderRadius: 8,
  color: '#e2e8f0',
};

export function QualidadeInicioCharts() {
  return (
    <Stack spacing={2}>
      <Alert severity="info" variant="outlined" sx={{ borderColor: 'divider' }}>
        <strong>Dados ilustrativos.</strong> Os indicadores abaixo são apenas para visualização do layout;
        na evolução do sistema serão alimentados por registros e métricas reais da API.
      </Alert>

      <Box
        sx={{
          display: 'grid',
          gap: 2,
          gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' },
        }}
      >
        <Paper sx={{ p: 2, minHeight: 320 }}>
          <Typography variant="subtitle2" fontWeight={700} gutterBottom>
            Registros por mês (exemplo)
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1.5 }}>
            Volume simulado de itens acompanhados no período.
          </Typography>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={DADOS_MENSAL} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.6} />
              <XAxis dataKey="mes" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} allowDecimals={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="registros" name="Registros" fill={CORES[0]} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Paper>

        <Paper sx={{ p: 2, minHeight: 320 }}>
          <Typography variant="subtitle2" fontWeight={700} gutterBottom>
            Distribuição por status (exemplo)
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1.5 }}>
            Proporção entre abertos, em tratamento e encerrados.
          </Typography>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={DADOS_STATUS}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={52}
                outerRadius={88}
                paddingAngle={2}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {DADOS_STATUS.map((_, i) => (
                  <Cell key={DADOS_STATUS[i].name} fill={CORES[i % CORES.length]} stroke="transparent" />
                ))}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 12, color: '#94a3b8' }} />
            </PieChart>
          </ResponsiveContainer>
        </Paper>

        <Paper sx={{ p: 2, minHeight: 320, gridColumn: { lg: '1 / -1' } }}>
          <Typography variant="subtitle2" fontWeight={700} gutterBottom>
            Tendência de resolutividade (exemplo)
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1.5 }}>
            Índice fictício (0–100) só para demonstrar série temporal.
          </Typography>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={DADOS_TENDENCIA} margin={{ top: 8, right: 16, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.6} />
              <XAxis dataKey="mes" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} domain={[0, 100]} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 12, color: '#94a3b8' }} />
              <Line
                type="monotone"
                dataKey="indice"
                name="Índice"
                stroke={CORES[1]}
                strokeWidth={2}
                dot={{ fill: CORES[1], r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Paper>
      </Box>
    </Stack>
  );
}
