import { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  type SelectChangeEvent,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import { api } from '../api';
import type { QualidadeRegistro, QualidadeRegistroStatus } from '../types';

const STATUS_LABEL: Record<QualidadeRegistroStatus, string> = {
  ABERTO: 'Aberto',
  EM_TRATAMENTO: 'Em tratamento',
  ENCERRADO: 'Encerrado',
};

function formatData(iso: string): string {
  try {
    return new Date(iso).toLocaleString('pt-BR', {
      dateStyle: 'short',
      timeStyle: 'short',
    });
  } catch {
    return iso;
  }
}

export function RegistrosQualidadeSection() {
  const [itens, setItens] = useState<QualidadeRegistro[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [updatingId, setUpdatingId] = useState<number | null>(null);

  const carregar = useCallback(async () => {
    setErr(null);
    setLoading(true);
    try {
      const lista = await api.listarRegistrosQualidade();
      setItens(lista);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Não foi possível carregar os registros.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void carregar();
  }, [carregar]);

  const handleCriar = async () => {
    const t = titulo.trim();
    if (!t) return;
    setSalvando(true);
    setErr(null);
    try {
      const criado = await api.criarRegistroQualidade({
        titulo: t,
        descricao: descricao.trim() || undefined,
      });
      setItens((prev) => [criado, ...prev]);
      setDialogOpen(false);
      setTitulo('');
      setDescricao('');
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Falha ao criar registro.');
    } finally {
      setSalvando(false);
    }
  };

  const handleStatusChange = async (id: number, status: QualidadeRegistroStatus) => {
    setUpdatingId(id);
    setErr(null);
    try {
      const atualizado = await api.atualizarRegistroQualidade(id, { status });
      setItens((prev) => prev.map((r) => (r.id === id ? atualizado : r)));
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Falha ao atualizar status.');
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <Stack spacing={2} sx={{ mt: 1 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1}>
        <Typography variant="subtitle1" fontWeight={700}>
          Registros de qualidade
        </Typography>
        <Button variant="contained" size="small" onClick={() => setDialogOpen(true)}>
          + Novo registro
        </Button>
      </Stack>
      <Typography variant="body2" color="text.secondary">
        Oportunidades de melhoria, acompanhamentos e registros operacionais de gestão da qualidade. Todos os usuários
        com acesso ao módulo podem visualizar e editar.
      </Typography>

      {err && (
        <Alert severity="error" onClose={() => setErr(null)}>
          {err}
        </Alert>
      )}

      {loading ? (
        <Typography color="text.secondary">Carregando…</Typography>
      ) : itens.length === 0 ? (
        <Paper variant="outlined" sx={{ p: 3, textAlign: 'center' }}>
          <Typography color="text.secondary">Nenhum registro ainda. Clique em &quot;Novo registro&quot;.</Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Título / descrição</TableCell>
                <TableCell width={160}>Status</TableCell>
                <TableCell width={200}>Responsável</TableCell>
                <TableCell width={140}>Atualizado</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {itens.map((r) => (
                <TableRow key={r.id}>
                  <TableCell>
                    <Typography fontWeight={600}>{r.titulo}</Typography>
                    {r.descricao ? (
                      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, whiteSpace: 'pre-wrap' }}>
                        {r.descricao}
                      </Typography>
                    ) : null}
                  </TableCell>
                  <TableCell>
                    <FormControl size="small" sx={{ minWidth: 160 }} disabled={updatingId === r.id}>
                      <InputLabel id={`st-${r.id}`}>Status</InputLabel>
                      <Select
                        labelId={`st-${r.id}`}
                        label="Status"
                        value={r.status}
                        onChange={(ev: SelectChangeEvent<QualidadeRegistroStatus>) => {
                          const next = ev.target.value as QualidadeRegistroStatus;
                          if (next === r.status) return;
                          void handleStatusChange(r.id, next);
                        }}
                      >
                        {(Object.keys(STATUS_LABEL) as QualidadeRegistroStatus[]).map((k) => (
                          <MenuItem key={k} value={k}>
                            {STATUS_LABEL[k]}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">{r.criadoPorNome}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      criado em {formatData(r.createdAt)}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" color="text.secondary">
                      {formatData(r.updatedAt)}
                    </Typography>
                    {r.atualizadoPorNome ? (
                      <Typography variant="caption" display="block" color="text.secondary">
                        por {r.atualizadoPorNome}
                      </Typography>
                    ) : null}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <Dialog open={dialogOpen} onClose={() => !salvando && setDialogOpen(false)} fullWidth maxWidth="sm">
        <DialogTitle>Novo registro</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Título"
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
              required
              fullWidth
              autoFocus
            />
            <TextField
              label="Descrição (opcional)"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              fullWidth
              multiline
              minRows={3}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)} disabled={salvando}>
            Cancelar
          </Button>
          <Button variant="contained" onClick={() => void handleCriar()} disabled={salvando || !titulo.trim()}>
            {salvando ? 'Salvando…' : 'Salvar'}
          </Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
