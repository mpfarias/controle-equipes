export interface Usuario {
  id: number;
  nome: string;
  matricula: string;
  equipe?: string;
  isAdmin?: boolean;
  nivelId?: number | null;
  nivel?: { id: number; nome: string; descricao?: string | null; ativo?: boolean };
  fotoUrl?: string | null;
  sistemasPermitidos?: string[];
}

export interface LoginInput {
  matricula: string;
  senha: string;
}

export type QualidadeRegistroStatus = 'ABERTO' | 'EM_TRATAMENTO' | 'ENCERRADO';

export type QualidadeRegistro = {
  id: number;
  titulo: string;
  descricao: string | null;
  status: QualidadeRegistroStatus;
  criadoPorId: number;
  criadoPorNome: string;
  atualizadoPorId: number | null;
  atualizadoPorNome: string | null;
  createdAt: string;
  updatedAt: string;
};
